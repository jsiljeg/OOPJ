package hr.fer.zemris.java.custom.collections;

/**
 * Klasa koja predstavlja procesor
 * 
 * @author Jure Šiljeg
 * @version 1.0.
 */
public class Processor {

	/**
	 * Metoda koja ne radi ništa.
	 * 
	 * @param value
	 *            referenca na neki tip podatka
	 */
	public void process(Object value) {

	}

}
