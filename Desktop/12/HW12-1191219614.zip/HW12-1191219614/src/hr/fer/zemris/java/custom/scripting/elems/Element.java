package hr.fer.zemris.java.custom.scripting.elems;

/**
 * Klasa koja predstavlja naš element. Gradimo pomoću nje hijerarhiju klasa.
 * 
 * @author Jure Šiljeg
 *
 */
public class Element {

	/**
	 * Služi za ispis.
	 * 
	 * @return ništa posebno.
	 */
	public String asText() {
		return "";
	}

}
