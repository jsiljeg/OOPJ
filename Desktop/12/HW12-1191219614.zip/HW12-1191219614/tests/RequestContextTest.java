
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import hr.fer.zemris.java.webserver.RequestContext;
import hr.fer.zemris.java.webserver.RequestContext.RCCookie;

@SuppressWarnings("javadoc")
public class RequestContextTest {

	@Test
	public void test1() throws IOException {
		demo1("primjer1.txt", "ISO-8859-2");
		String textToCompare = "HTTP/1.1 205 Idemo dalje\r\nContent-type: text/plain; charset=ISO-8859-2;\r\n\r\n�evap�i�i i �i��evap�i�i.";
		String text = readFromDisk("primjer1.txt");
		assertEquals(text, textToCompare);
	}

	@Test
	public void test2() throws IOException {
		demo1("primjer2.txt", "UTF-8");
		String textToCompare = "HTTP/1.1 205 Idemo dalje\r\nContent-type: text/plain; charset=UTF-8;\r\n\r\nČevapčići i Šiščevapčići.";
		String text = readFromDisk("primjer2.txt");
		System.out.println(textToCompare);
		System.out.println(text);
		assertEquals(text, textToCompare);
	}

	@Test
	public void test3() throws IOException {
		demo2("primjer3.txt", "UTF-8");
		String textToCompare = "HTTP/1.1 205 Idemo dalje\r\nContent-type: text/plain; charset=UTF-8;\r\n"
				+ "Set-Cookie: korisnik=\"perica\"; Domain=\"127.0.0.1\"; Path=\"/\"; Max-Age=3600; HttpOnly\r\n"
				+ "Set-Cookie: zgrada=\"B4\"; Path=\"/\"; HttpOnly\r\n\r\nČevapčići i Šiščevapčići.";
		String text = readFromDisk("primjer3.txt");
		assertEquals(text, textToCompare);
	}

	private static void demo1(String filePath, String encoding) throws IOException {
		OutputStream os = Files.newOutputStream(Paths.get(filePath));
		RequestContext rc = new RequestContext(os, new HashMap<String, String>(), new HashMap<String, String>(),
				new ArrayList<RequestContext.RCCookie>());
		rc.setEncoding(encoding);
		rc.setMimeType("text/plain");
		rc.setStatusCode(205);
		rc.setStatusText("Idemo dalje");
		// Only at this point will header be created and written...
		rc.write("Čevapčići i Šiščevapčići.");
		os.close();
	}

	private static void demo2(String filePath, String encoding) throws IOException {
		OutputStream os = Files.newOutputStream(Paths.get(filePath));
		RequestContext rc = new RequestContext(os, new HashMap<String, String>(), new HashMap<String, String>(),
				new ArrayList<RequestContext.RCCookie>());
		rc.setEncoding(encoding);
		rc.setMimeType("text/plain");
		rc.setStatusCode(205);
		rc.setStatusText("Idemo dalje");
		rc.addRCCookie(new RCCookie("korisnik", "perica", 3600, "127.0.0.1", "/"));
		rc.addRCCookie(new RCCookie("zgrada", "B4", null, null, "/"));
		// Only at this point will header be created and written...
		rc.write("Čevapčići i Šiščevapčići.");
		os.close();
	}

	private String readFromDisk(String fileName) {
		String docBody = "";
		try {
			docBody = new String(Files.readAllBytes(Paths.get(fileName)), StandardCharsets.UTF_8);
		} catch (IOException e) {
			System.err.println("File not found!");
			System.exit(0);
		}
		return docBody;
	}
}
