/**
 * Paket koji koristimo kao "vršni razred" komandama i ima osnovne metode za
 * obradu ispravnosti unosa argumenata koji bi trebali biti staza te može
 * dohvatiti i pohraniti internu listu s opisom funkcionalnosti komandi.
 * 
 * @author Jure Šiljeg
 *
 */
package hr.fer.zemris.java.tecaj.hw07.shell.commands.support;