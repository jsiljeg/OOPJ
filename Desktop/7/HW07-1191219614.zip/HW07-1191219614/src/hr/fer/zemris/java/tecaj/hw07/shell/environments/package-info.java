/**
 * Paket koji reprezentira okruženje u kojem se "ljuska odvija".
 * 
 * @author Jure Šiljeg
 *
 */
package hr.fer.zemris.java.tecaj.hw07.shell.environments;