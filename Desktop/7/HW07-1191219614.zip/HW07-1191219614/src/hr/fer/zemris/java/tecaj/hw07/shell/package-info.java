/**
 * Paket koji omogućuje rad s ljuskom. Primitivna i jednostavna verzija nekih
 * funkcionalnosti LINUX-ovog terminala.
 * 
 * @author Jure Šiljeg
 *
 */
package hr.fer.zemris.java.tecaj.hw07.shell;