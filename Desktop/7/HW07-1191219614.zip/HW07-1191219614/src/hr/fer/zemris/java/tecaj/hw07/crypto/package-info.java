/**
 * Paket koji dočarava rad s enkripcijom i dekripcijom datoteka koristeći 128
 * bitni ključ i SHA-256.
 * 
 * @author Jure Šiljeg
 *
 */
package hr.fer.zemris.java.tecaj.hw07.crypto;